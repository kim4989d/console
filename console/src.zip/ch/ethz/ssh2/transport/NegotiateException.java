package ch.ethz.ssh2.transport;

/**
 * NegotiateException.
 * 
 * @author Christian Plattner, plattner@inf.ethz.ch
 * @version $Id: NegotiateException.java,v 1.1 2009/02/09 06:57:30 kim4989 Exp $
 */
public class NegotiateException extends Exception
{
	private static final long serialVersionUID = 3689910669428143157L;
}
