package console.common.tray;

import java.io.Serializable;

public class NomalTray extends AbstractTray implements Serializable {

}
