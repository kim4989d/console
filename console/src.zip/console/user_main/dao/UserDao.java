package console.user_main.dao;

public class UserDao
{

}
