package console.list;

public class BoardBean {

	private int num;
	private String name; ;
	private String email;
	private String homepage;
	private String subject;
	private String content;
	private int pos;
	private int depth;
	private String regdate;
	private String pass;
	private int count;
	private String ip;

	public void setNum(int num) {
		this.num = num;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public void setHomepage(String homepage) {
		this.homepage = homepage;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public void setPos(int pos) {
		this.pos = pos;
	}
	public void setDepth(int depth) {
		this.depth = depth;
	}
	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}

	public int getNum() {
		return num;
	}
	public String getName() {
		return name;
	}
	public String getEmail() {
		return email;
	}
	public String getHomepage() {
		return homepage;
	}
	public String getSubject() {
		return subject;
	}
	public String getContent() {
		return content;
	}
	public int getPos() {
		return pos;
	}
	public int getDepth() {
		return depth;
	}
	public String getRegdate() {
		return regdate;
	}
	public String getPass() {
		return pass;
	}
	public int getCount() {
		return count;
	}
	public String getIp() {
		return ip;
	}
}