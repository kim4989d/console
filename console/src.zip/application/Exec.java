package application;

public class Exec {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		CmdExecutor cmd=new CmdExecutor();
		cmd.execute("cmd.exe");
	}

}
