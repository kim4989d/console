package test;


import java.util.*;
public class str {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		StringTokenizer str=new StringTokenizer("");
		while(str.hasMoreElements()){
		
			str.nextToken();
			
			
			
		}
	}

}
