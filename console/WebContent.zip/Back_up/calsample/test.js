function test()
{
	window.alert();
}